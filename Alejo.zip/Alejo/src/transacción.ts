type TipoMovimiento = "ingreso" | "egreso";

interface Transaccion {
    monto: number;
    tipo: TipoMovimiento;
    categoria: string;
}

interface Balance {
    ingreso: number;
    egreso: number;
}

function agruparPorTipo(transacciones: Transaccion[]): Balance {
    return transacciones.reduce((acumulador, transaccion) => {
        acumulador[transaccion.tipo] += transaccion.monto;
        return acumulador;
    }, { ingreso: 0, egreso: 0 });
}

const miHistorial: Transaccion[] = [
    { monto: 100, tipo: "ingreso", categoria: "Sueldo" },
    { monto: 20, tipo: "egreso", categoria: "Transporte" },
    { monto: 50, tipo: "ingreso", categoria: "Venta" },
    { monto: 30, tipo: "egreso", categoria: "Comida" },
];

const totales = agruparPorTipo(miHistorial);

console.log("Resumen de transacciones:");
console.log(`Total Ingresos: $${totales.ingreso}`);
console.log(`Total Egresos: $${totales.egreso}`);
console.log(`Balance Neto: $${totales.ingreso - totales.egreso}`);