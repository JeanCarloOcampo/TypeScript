type Estado = "pendiente" | "en_progreso" | "finalizada";

interface Tarea {
    id: number;
    descripcion: string;
    completada: boolean;
    estado: Estado;
}

function obtenerTareasActivas(lista: Tarea[]): Tarea[] {
    return lista.filter(tarea => 
        tarea.estado === "pendiente" || tarea.estado === "en_progreso"
    );
}

const misTareas: Tarea[] = [
    { id: 1, descripcion: "Aprender TypeScript", completada: false, estado: "en_progreso" },
    { id: 2, descripcion: "Ver Netflix", completada: true, estado: "finalizada" },
    { id: 3, descripcion: "Lavar la ropa", completada: false, estado: "pendiente" }
];

const tareasPorHacer = obtenerTareasActivas(misTareas);

console.log("Tareas activas (Pendientes o En Progreso):");
console.log(tareasPorHacer);