interface NotificacionEmail {
    tipo: "email";
    correo: string;
    asunto: string;
    mensaje: string;
}

interface NotificacionSMS {
    tipo: "sms";
    telefono: number;
    mensaje: string;
}

interface NotificacionPush {
    tipo: "push";
    usuarioId: string;
    titulo: string;
    mensaje: string;
}

type Notificacion = NotificacionEmail | NotificacionSMS | NotificacionPush;

function enviarNotificacion(notificacion: Notificacion): void {
    switch (notificacion.tipo) {
        case "email":
            console.log(`Enviando Email a ${notificacion.correo}: [${notificacion.asunto}] ${notificacion.mensaje}`);
            break;
            
        case "sms":
            console.log(`Enviando SMS al número ${notificacion.telefono}: ${notificacion.mensaje}`);
            break;
            
        case "push":
            console.log(`Enviando Notificación Push al usuario ${notificacion.usuarioId}: ${notificacion.titulo}`);
            break;
    }
}

const miNotificacion: Notificacion = {
    tipo: "sms",
    telefono: 3101234567,
    mensaje: "Tu código de acceso es 8892"
};

enviarNotificacion(miNotificacion);