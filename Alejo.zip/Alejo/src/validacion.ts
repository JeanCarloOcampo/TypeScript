type TipoCampo = "texto" | "numero" | "email";

interface CampoFormulario {
    nombre: string;
    tipo: TipoCampo;
    valor: string | number;
}

function validarFormulario(campos: CampoFormulario[]): string[] {
    const camposInvalidos: string[] = [];

    campos.forEach(campo => {
        const { tipo, valor, nombre } = campo;

        if (tipo === "numero") {
            if (typeof valor !== "number" || isNaN(valor)) {
                camposInvalidos.push(nombre);
            }
        } 
        else if (tipo === "email") {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (typeof valor !== "string" || !emailRegex.test(valor)) {
                camposInvalidos.push(nombre);
            }
        } 
        else if (tipo === "texto") {
            if (typeof valor !== "string" || valor.trim() === "") {
                camposInvalidos.push(nombre);
            }
        }
    });

    return camposInvalidos;
}

const miFormulario: CampoFormulario[] = [
    { nombre: "usuario", tipo: "texto", valor: "JeanCarlo" },
    { nombre: "edad", tipo: "numero", valor: "17" },
    { nombre: "correo", tipo: "email", valor: "jjsf@gmail.com" },
    { nombre: "puntos", tipo: "numero", valor: 100 }
];

const errores = validarFormulario(miFormulario);

if (errores.length > 0) {
    console.log(`Campos con errores: ${errores.join(", ")}`);
} else {
    console.log("¡Formulario válido!");
}